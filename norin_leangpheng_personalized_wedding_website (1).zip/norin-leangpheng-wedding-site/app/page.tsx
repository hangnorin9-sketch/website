import { WeddingPage } from "./components";
export default function Home() { return <WeddingPage guest="our special guest" />; }