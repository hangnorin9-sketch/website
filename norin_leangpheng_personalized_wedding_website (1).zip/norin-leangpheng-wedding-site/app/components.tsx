'use client';
import { useEffect, useState } from "react";

export function WeddingPage({ guest }: { guest: string }) {
  const [coverOpen, setCoverOpen] = useState(true);
  const [time, setTime] = useState({ days: "--", hours: "--", minutes: "--", seconds: "--" });
  useEffect(() => {
    const target = new Date("2026-11-22T18:00:00+07:00").getTime();
    const tick = () => {
      let d = Math.max(0, target - Date.now());
      setTime({days:String(Math.floor(d/86400000)),hours:String(Math.floor(d%86400000/3600000)).padStart(2,"0"),minutes:String(Math.floor(d%3600000/60000)).padStart(2,"0"),seconds:String(Math.floor(d%60000/1000)).padStart(2,"0")});
    };
    tick(); const id = setInterval(tick,1000); return () => clearInterval(id);
  }, []);
  const Flower = () => <svg className="flower" viewBox="0 0 120 54" aria-hidden="true"><g fill="none" stroke="#b6a16b" strokeWidth="1"><path d="M60 27C42 27 42 7 60 3C78 7 78 27 60 27ZM60 27C42 27 42 47 60 51C78 47 78 27 60 27ZM60 27C60 9 40 9 36 27C40 45 60 45 60 27ZM60 27C60 9 80 9 84 27C80 45 60 45 60 27ZM10 27H36M84 27H110"/><circle cx="60" cy="27" r="4"/></g></svg>;
  const Ornament = ({cls}:{cls:string}) => <svg className={`ornament ${cls}`} viewBox="0 0 160 160" aria-hidden="true"><g fill="none" stroke="#8eaa8e" strokeWidth="1.2"><path d="M10 150C15 85 45 30 150 10M15 115C35 95 55 75 80 72M40 55C25 40 25 22 42 13C60 25 58 43 40 55ZM76 73C60 56 63 38 82 30C97 46 95 63 76 73ZM111 39C99 24 105 11 121 8C135 21 129 34 111 39Z"/></g></svg>;
  return <main className="site">
    <div className={`cover ${coverOpen ? "" : "closed"}`}><div className="cover-card"><Ornament cls="tl"/><Ornament cls="br"/>
      <div className="kicker">សិរីមង្គលអាពាហ៍ពិពាហ៍</div><div className="smallcaps" style={{marginTop:22}}>The Wedding Invitation</div>
      <div className="cover-names">Hang Norin</div><div className="amp">&</div><div className="cover-names" style={{marginTop:8}}>Lor Leangpheng</div>
      <div className="rule"/><div className="date-big">22 · 11 · 2026</div>
      <div className="guest-chip">With love for {guest}</div>
      <button className="open-btn" onClick={()=>{setCoverOpen(false);setTimeout(()=>document.getElementById("home")?.scrollIntoView({behavior:"smooth"}),100)}}>Tap to Open</button>
      <div className="khmer" style={{marginTop:20,fontSize:12}}>សូមចុចដើម្បីបើកសំបុត្រអញ្ជើញ</div>
    </div></div>
    <section className="hero" id="home"><div className="kicker">សូមគោរពអញ្ជើញ</div><div className="smallcaps" style={{marginTop:15}}>Together with our families</div>
      <h1>Hang Norin</h1><div className="amp">&</div><h1 style={{marginTop:0}}>Lor Leangpheng</h1>
      <div className="subtitle">joyfully invite</div><div className="khmer" style={{marginTop:8}}>សូមគោរពអញ្ជើញ</div><div className="guest-chip">Dear {guest}</div>
      <Flower/><div className="date-big">22 NOVEMBER 2026</div><div className="date-sub">ថ្ងៃអាទិត្យ ទី២២ ខែវិច្ឆិកា ឆ្នាំ២០២៦</div>
      <div className="rule"/><div className="subtitle">6:00 PM</div><div className="date-sub">We would be honored by your presence</div>
    </section>
    <section className="invite"><div className="invite-inner"><div className="section-label">A special invitation</div><h2>With love & happiness</h2>
      <p className="khmer">យើងខ្ញុំមានកិត្តិយស សូមគោរពអញ្ជើញ លោកអ្នកចូលរួមជាភ្ញៀវកិត្តិយស ក្នុងពិធីមង្គលការរបស់យើងខ្ញុំ ដើម្បីចែករំលែកនូវក្ដីស្រឡាញ់ និងសុភមង្គលក្នុងថ្ងៃដ៏មានអត្ថន័យនេះ។</p>
      <div className="rule"/><div className="smallcaps">Save the date</div><div style={{fontSize:26,marginTop:8}}>Sunday · 22 November 2026</div><div className="khmer" style={{marginTop:8}}>វេលាម៉ោង ៦:០០ ល្ងាច</div>
    </div></section>
    <section><div className="section-label">The celebration</div><h2>Wedding Details</h2><p className="khmer">សូមអញ្ជើញចូលរួមអបអរសាទរ និងជូនពរដល់គូស្វាមីភរិយាថ្មី</p>
      <div className="schedule"><div className="schedule-item"><div className="schedule-time">6:00 PM</div><div className="smallcaps">Welcome</div><div className="schedule-desc">ទទួលភ្ញៀវកិត្តិយស</div></div><div className="schedule-item"><div className="schedule-time">Evening</div><div className="smallcaps">Wedding Reception</div><div className="schedule-desc">ពិធីជប់លៀងអាពាហ៍ពិពាហ៍</div></div></div>
      <div className="location-card"><div style={{fontSize:28,color:"var(--gold)"}}>⌖</div><h2 style={{fontSize:32,margin:"10px 0"}}>Venue</h2><p className="khmer">ទីតាំងពិធីមង្គលការ</p><p style={{fontSize:18,color:"#718674"}}>We look forward to celebrating with you.</p><a className="map-btn" href="https://maps.app.goo.gl/8gbSTjLY" target="_blank" rel="noreferrer">OPEN MAP ↗</a></div>
    </section>
    <section style={{background:"#f0f6ed"}}><div className="section-label">Counting down</div><h2>Until our big day</h2><p className="khmer">រាប់ថយក្រោយទៅកាន់ថ្ងៃដ៏ពិសេសរបស់យើង</p>
      <div className="countdown">{Object.entries(time).map(([label,value])=><div className="countbox" key={label}><strong>{value}</strong><span>{label}</span></div>)}</div>
    </section>
    <section className="closing"><Flower/><div className="section-label">With grateful hearts</div><h2>We can't wait to see you</h2><p className="khmer">វត្តមានរបស់លោកអ្នក គឺជាកិត្តិយស និងជាសេចក្ដីរីករាយដ៏ធំធេងសម្រាប់យើងខ្ញុំ។</p><div className="footer-names">Norin & Leangpheng</div><div className="smallcaps">22 · 11 · 2026</div></section>
    <footer>MADE WITH LOVE · WEDDING INVITATION</footer>
  </main>;
}

export function GuestAdmin() {
  const [baseUrl, setBaseUrl] = useState("https://your-wedding-site.vercel.app");
  const [guestName, setGuestName] = useState("");
  const [rows, setRows] = useState<{name:string;url:string}[]>([]);
  const [message, setMessage] = useState("");

  const makeUrl = (name: string) => {
    const cleanBase = baseUrl.trim().replace(/\/$/, "");
    const slug = name.trim().replace(/\s+/g, "-");
    return `${cleanBase}/invitation/${encodeURIComponent(slug)}`;
  };

  const addGuest = () => {
    const name = guestName.trim().replace(/\s+/g, " ");
    if (!name) { setMessage("Please enter a guest name first."); return; }
    if (!baseUrl.trim()) { setMessage("Please enter your published website URL."); return; }
    if (rows.some(row => row.name.toLowerCase() === name.toLowerCase())) {
      setMessage("That guest is already in your list. You can copy their existing link below.");
      return;
    }
    setRows(current => [...current, {name, url: makeUrl(name)}]);
    setGuestName("");
    setMessage(`Personal invitation link created for ${name}.`);
  };

  const exportCsv = () => {
    const content = [["Guest Name","Invitation Link"], ...rows.map(r=>[r.name,r.url])].map(row=>row.map(v=>`"${v.replace(/"/g,'""')}"`).join(",")).join("\r\n");
    const blob = new Blob(["\ufeff"+content],{type:"text/csv;charset=utf-8;"});
    const link = document.createElement("a");link.href=URL.createObjectURL(blob);link.download="wedding-guest-links.csv";link.click();URL.revokeObjectURL(link.href);
  };

  const copyText = async (value: string, success: string) => {
    try { await navigator.clipboard.writeText(value); setMessage(success); }
    catch { setMessage("Clipboard access was blocked by your browser. You can select and copy the link manually."); }
  };

  return <main className="admin">
    <div className="kicker">Wedding Invitation Manager</div>
    <h1>Guest Link Generator</h1>
    <p>Enter one guest's name to create their personal wedding invitation link. Repeat for your 100–300 guests, then export the full list as a CSV.</p>
    <label htmlFor="base">Your published website URL</label>
    <input id="base" value={baseUrl} onChange={e=>{setBaseUrl(e.target.value);setRows(current=>current.map(r=>({...r,url:`${e.target.value.trim().replace(/\/$/,"")}/invitation/${encodeURIComponent(r.name.replace(/\s+/g,"-"))}`})));}} placeholder="https://your-site.vercel.app"/>
    <label htmlFor="guestName">Guest name</label>
    <input id="guestName" value={guestName} onChange={e=>setGuestName(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")addGuest();}} placeholder="e.g. Sok Dara"/>
    <div className="actions">
      <button className="primary" onClick={addGuest}>Create guest link</button>
      <button className="primary" onClick={()=>setGuestName("")}>Clear name</button>
    </div>
    {message && <p role="status" className="note">{message}</p>}
    <p className="note">Your guest list is kept in this browser session only. Export the CSV before closing or refreshing the page. Guest names are not uploaded to a server.</p>
    {rows.length>0 && <>
      <h2 style={{fontSize:30,marginTop:30}}>Your guest list ({rows.length})</h2>
      <div className="actions">
        <button className="primary" onClick={exportCsv}>Export CSV</button>
        <button className="primary" onClick={()=>copyText(rows.map(r=>`${r.name}\t${r.url}`).join("\n"),"All guest names and links copied.")}>Copy all links</button>
        <button className="primary" onClick={()=>{if(confirm("Clear the guest list from this browser session?")){setRows([]);setMessage("Guest list cleared.");}}}>Clear list</button>
      </div>
      <div className="table-wrap"><table><thead><tr><th>Guest name</th><th>Personal invitation link</th><th>Action</th></tr></thead><tbody>
        {rows.map((r,i)=><tr key={`${r.name}-${i}`}><td>{r.name}</td><td><a href={r.url} target="_blank" rel="noreferrer">{r.url}</a></td><td><button className="primary" style={{margin:0,padding:"7px 10px"}} onClick={()=>copyText(r.url,`Link copied for ${r.name}.`)}>Copy link</button></td></tr>)}
      </tbody></table></div>
    </>}
    <p className="note" style={{marginTop:28}}>This tool creates and organizes links; it does not automatically send invitations or collect RSVPs. Share each link with the intended guest through Telegram, Messenger, or email.</p>
  </main>;
}
