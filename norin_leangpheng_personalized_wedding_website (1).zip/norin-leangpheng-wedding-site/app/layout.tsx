import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Hang Norin & Lor Leangpheng | Wedding Invitation",
  description: "A Khmer wedding invitation for Hang Norin and Lor Leangpheng — 22 November 2026."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}