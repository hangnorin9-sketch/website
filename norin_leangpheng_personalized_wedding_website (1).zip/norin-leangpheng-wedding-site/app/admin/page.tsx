import { GuestAdmin } from "../components";
export default function AdminPage() { return <GuestAdmin />; }