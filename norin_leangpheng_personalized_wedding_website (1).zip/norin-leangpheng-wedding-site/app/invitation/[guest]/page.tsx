import { WeddingPage } from "../../components";
export default async function Invitation({ params }: { params: Promise<{ guest: string }> }) {
  const { guest } = await params;
  const name = decodeURIComponent(guest).replace(/-/g, " ").trim() || "our special guest";
  return <WeddingPage guest={name} />;
}