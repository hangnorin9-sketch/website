# Hang Norin & Lor Leangpheng — Wedding Invitation

A Next.js wedding invitation website with:
- White and matcha-green Khmer-inspired floral design
- Opening cover and guest name personalization
- Wedding date/time and countdown
- Google Maps button
- Individual guest link generator at `/admin` (add names one by one; export the accumulated list to CSV)
- CSV export for guest names and personal invitation links

## Run locally
1. Install Node.js (18.17+ recommended).
2. In this folder run `npm install`.
3. Run `npm run dev`.
4. Open `http://localhost:3000`.
5. Open `http://localhost:3000/admin` to generate guest links.

## Deploy to Vercel
1. Upload this project to a GitHub repository.
2. Import the repository in Vercel and deploy with the default Next.js settings.
3. Open `https://YOUR-VERCEL-DOMAIN/admin`.
4. Replace the default URL in the generator with your real published domain.
5. Paste your guest names, one per line, click **Generate personalized links**, then **Export CSV**.

## URL format
A generated link uses `/invitation/Guest-Name`, for example:
`https://YOUR-VERCEL-DOMAIN/invitation/Sok-Dara`

The URL slug is displayed as a readable name on the invitation. This starter project does not store guest records on a server, send messages, or collect RSVPs. The admin tool runs in the browser only; its guest list is temporary, so export the CSV before refreshing or closing the page.

## Important details to confirm before sending
- Replace the sample Google Maps link in `app/components.tsx` if the venue pin changes.
- The invitation currently uses 6:00 PM Cambodia time on 22 November 2026.
- Add a photo or venue name if desired before publishing.
